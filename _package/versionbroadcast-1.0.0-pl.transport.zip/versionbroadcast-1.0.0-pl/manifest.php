<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 Thomas Gautvedt <thomas.gautvedt@catchmedia.no>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# MODX Version Broadcast

This README is written in Markdown. If you read this in the MODX manager, it may be better to read it here: https://github.com/catchmediano/modx-version-broadcast

A MODX Revolution extra that exposes the current MODX version via a secure REST endpoint. The data is secured by validating a secret request token.

**Security notice: It is very important that the MODX Revolution version is kept secret via a secure endpoint. There exists serious exploits and bugs that can be used to hack your site. If your site is not up to date with the latest version, and hackers find your current installed version, it is a serious security threat. The authors of this extra takes no responsibility for any problems that might be caused by using this software. See the license.**

## Requirements

Please let us know if you have problems with this software and you meet the requirements.

* PHP  >= 5.5 (because of use of  [`password_hash`](http://php.net/password_hash) and [`password_verify`](http://php.net/password_verify))
* MODX Revolution >= 2.2

## Generate the Endpoint URL

If you lost the endpoint URL, you can generate it yourself by copying the following snippet and running it on your site:

```
$path = $modx->getOption(\'versionbroadcast.core_path\', null, $modx->getOption(\'core_path\') . \'components/versionbroadcast/\');
$versionBroadcast = $modx->getService(\'versionbroadcast\', \'VersionBroadcast\', $path . \'model/versionbroadcast/\');
if (!($versionBroadcast instanceof VersionBroadcast)) {
    $modx->log(\\modX::LOG_LEVEL_ERROR, \'Could not load VersionBroadcast class\');
    return;
}

$modx->log(\\modX::LOG_LEVEL_ERROR, \'Endpoint URL: \' . $versionBroadcast->getEndpoint());
```

The endpoint will be logged to the Error log found in the manager interface.

Note that this URL is without the base URL prefix. This is because the plugin runs across all contexts. This means that if you have a site with base URL `http://www.site.tld`, and the endpoint URL is `rest/versionbroadcast?token=foobar`, then the final URL is `http://www.site.tld/rest/versionbroadcast?token=foobar`.

## Report Problems

If you encounter a problem with this software, please create a [issue](https://github.com/catchmediano/modx-version-broadcast/issues) on the official [GitHub repository](https://github.com/catchmediano/modx-version-broadcast/). You can also get in touch with the author on the [MODX Community Slack](https://modx.org) with the user @optimuscrime. 

## Contribute

Feel free to fork or contribute to the extra.
',
    'changelog' => '1.0.0-pl
====================================
- Initial release
',
    'setup-options' => 'versionbroadcast-1.0.0-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3987695aa4cf2536794c30607bd5efd4',
      'native_key' => 'versionbroadcast',
      'filename' => 'modNamespace/7b0acbaa86de018a85cde234929fc24e.vehicle',
      'namespace' => 'versionbroadcast',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '58f36abd2875fd585a83de5606a4e56f',
      'native_key' => NULL,
      'filename' => 'modPlugin/6c96243d14b35fcf400f6f3051416e0c.vehicle',
      'namespace' => 'versionbroadcast',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d3d880f65e802f7b2ea15e9dd097fa2',
      'native_key' => 'versionbroadcast.secret',
      'filename' => 'modSystemSetting/f9ef8cbbfd68999ea8dea8c4b605ce5e.vehicle',
      'namespace' => 'versionbroadcast',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8faa8cd75f4f6eb0fe2fd95f1a1a80a7',
      'native_key' => 'versionbroadcast.salt',
      'filename' => 'modSystemSetting/4e8462e9d265f01f7a0a5ab5cf34be7b.vehicle',
      'namespace' => 'versionbroadcast',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbca35eb6b03b29f45660edebd201977',
      'native_key' => 'versionbroadcast.uri',
      'filename' => 'modSystemSetting/05428e0d0e634e7073955bafadc93732.vehicle',
      'namespace' => 'versionbroadcast',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c749f8b170d3f65e3d078765ec94803',
      'native_key' => 'versionbroadcast.token_param',
      'filename' => 'modSystemSetting/5a427ed3fa23ea1842495d0f6a03284c.vehicle',
      'namespace' => 'versionbroadcast',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a0a2632d033f243b1fc4fe52ae50563c',
      'native_key' => NULL,
      'filename' => 'modCategory/95b2715d1af485df7629af76a6e77da6.vehicle',
      'namespace' => 'versionbroadcast',
    ),
  ),
);